#HASAN TAHIR
#ID: 29591732
#Last edit: 3/05/2018
class WordAnalyser:
 word_dictionary={}
 def __init__(self):
  word_dictionary={}

 def __str__(self):
   print('Statistics for Words :'+str(self.word_dictionary))
   for key, value in self.word_dictionary.items():
    print(key, '-', value)
   return str(self.word_dictionary)

 def analyse_words(self,decoded_sequence):
   self.word_dictionary={}
   i=0
   m=0
   while i<len(decoded_sequence):
    # this punctuation marks are seperating the words from each other
    if decoded_sequence[i]==" " or  decoded_sequence[i]=="?" or  decoded_sequence[i]=="." or  decoded_sequence[i]==",":
     word=decoded_sequence[m:i]
     m=i+1  
     # creating word dictionary
     if word!="":
      if word in self.word_dictionary:
       self.word_dictionary[word] += 1
      else:
       self.word_dictionary[word] = 1
    i=i+1

   word=decoded_sequence[m:i]
   # this is for the last word in the decoded sequence.
   if word!="": 
    if word in self.word_dictionary:
     self.word_dictionary[word] += 1
    else:
     self.word_dictionary[word] = 1
   #printing and returning dictionary data.  
   self.__str__() 
