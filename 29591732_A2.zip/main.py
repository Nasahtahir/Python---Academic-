#HASAN TAHIR
#ID: 29591732
#Last edit: 2/05/2018

from character import *
from decoder import * 
from sentence import *
from word import *
# initialised dictionary to print at the first time on the execution of the main function.
MORSE_CODE = {
    '01'    : 'A',
    '1000'  : 'B',
    '1010'  : 'C',
    '100'   : 'D',
    '0'     : 'E',
    '0010'  : 'F',
    '110'   : 'G',
    '0000'  : 'H',
    '00'    : 'I',
    '0111'  : 'J',
    '101'   : 'K',
    '0100'  : 'L',
    '11'    : 'M',
    '10'    : 'N',
    '111'   : 'O',
    '0110'  : 'P',
    '1101'  : 'Q',
    '010'   : 'R',
    '000'   : 'S',
    '1'     : 'T',
    '001'   : 'U',
    '0001'  : 'V',
    '011'   : 'W',
    '1001'  : 'X',
    '1011'  : 'Y',
    '1100'  : 'Z',
    '11111' : '0',
    '01111' : '1',
    '00111' : '2',
    '00011' : '3',
    '00001' : '4',
    '00000' : '5',
    '10000' : '6',
    '11000' : '7',
    '11100' : '8',
    '11110' : '9',
    '010101' : '.',
    '110011' : ',',
    '001100' : '?'
}

#printing MORSE_CODE in sorted value upon calling of main function .
def print_code(code):
    '''
    Print morse code table
    '''
    for key, value in sorted(code.items()):
        # Display a character and then its morse code presentation
        print(value, '-', key)



def main():
  print_code(MORSE_CODE)
  hasSpace=False
  #creating objects of each of the four classes.
  ca=CharacterAnalyser()
  wa=WordAnalyser()
  dec=Decoder()
  sen=SentenceAnalyser()
  # loop ends when user give 'Q' input to Quit the program.
  while True:
        print('Enter "Q" to exit.')
        user_input = input('Enter a Morse code sequence:')
        if len(user_input) >0:
          print(user_input)
        i=0
        #loop for checking that the input must have atleast one '***' in input string.
        while i<len(user_input):
          if user_input[i]=='*':
           if i+2<len(user_input):        
            if user_input[i+1]=='*' and user_input[i+2]=='*':
             hasSpace=True
             i=i+2
          i=i+1
        if hasSpace==False:
           print("Invalid Input")
        else:
         # calling decode function which decodes the morse code
         dec.decode(user_input)
         #analysing characters of decoded code using analyse_character function of CharacterAnalyser class .
         ca.analyse_characters(dec.decoded_code)
         #analysing words  of decoded code using analyse_words function of WordAnalyser class .
         wa.analyse_words(dec.decoded_code)
         #analysing sentences  of decoded code using analyse_sentences  function of SentenceAnalyser class .
         sen.analyse_sentences(dec.decoded_code)
        # Termination case
        if user_input == 'Q':
          print("Exiting..")
          break


#How to think like a computer scientist; Book used. Running everything written above.
if __name__ == '__main__':
 main()



