#HASAN TAHIR
#ID: 29591732
#Last edit: 01/05/2018
from main import *
class Decoder:
  #variable declaration.
  MORSE_CODE={} 
  decoded_code=""
  
  # constructor for intialising and assigning of MORSE_CODE dictionary
  def  __init__(self):
   self.MORSE_CODE = {
    '01'    : 'A',
    '1000'  : 'B',
    '1010'  : 'C',
    '100'   : 'D',
    '0'     : 'E',
    '0010'  : 'F',
    '110'   : 'G',
    '0000'  : 'H',
    '00'    : 'I',
    '0111'  : 'J',
    '101'   : 'K',
    '0100'  : 'L',
    '11'    : 'M',
    '10'    : 'N',
    '111'   : 'O',
    '0110'  : 'P',
    '1101'  : 'Q',
    '010'   : 'R',
    '000'   : 'S',
    '1'     : 'T',
    '001'   : 'U',
    '0001'  : 'V',
    '011'   : 'W',
    '1001'  : 'X',
    '1011'  : 'Y',
    '1100'  : 'Z',
    '11111' : '0',
    '01111' : '1',
    '00111' : '2',
    '00011' : '3',
    '00001' : '4',
    '00000' : '5',
    '10000' : '6',
    '11000' : '7',
    '11100' : '8',
    '11110' : '9',
    '010101' : '.',
    '110011' : ',',
    '001100' : '?'
    }
   #we have declared STATS but we are not using it .
   self.STATS={}


   
  #returns string of decoded code in readable format.
  def __str__(self):
   return self.decoded_code
  #decodes the morse code input sequence.
  def decode(self,morse_code_sequence):
    temp_code=""
    i=0
    m=0
    while i<len(morse_code_sequence):
     if morse_code_sequence[i]=='*':        
      #a is a temp variable holding morse code till * is found on every loop
      a=morse_code_sequence[m:i]
      m=i+1   
      if a in self.MORSE_CODE:
       temp_code=temp_code+self.MORSE_CODE[a]

      else:
       if a!="":
        print('No such morse code sequence. Please try again')       
        return
      if i+2<len(morse_code_sequence): 
       if morse_code_sequence[i+1]=='*' and morse_code_sequence[i+2]=='*':
        #Adding space when *** is found in morse code
        temp_code=temp_code+" "
        i=i+2
        m=i+1
     i=i+1
    #for the last set of morse code to be decoded.
    a=morse_code_sequence[m:i]
    if  a  in self.MORSE_CODE:
     temp_code=temp_code+self.MORSE_CODE[a]
    else:
     if a!="":
      print('No such morse code sequence. Please try again')
      return

    self.decoded_code=temp_code
    #printing decoded code from morse code.
    print("Decoded string  is : "+self.decoded_code)

