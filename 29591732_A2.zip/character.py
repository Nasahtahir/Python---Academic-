#HASAN TAHIR
#ID: 29591732
#Last edit: 28/04/2018
class CharacterAnalyser:
 char_dictionary={}

 #initialising the character dictionary, with no key-value pairs at the time of initialisation.
 def __init__(self):
  self.char_dictionary={}

 #prints and returns statistics of characters as a string .
 def __str__(self):
  print('Statistics for characters :'+str(self.char_dictionary))  
  for key, value in self.char_dictionary.items():
    print(key, '-', value) 
  return str(self.char_dictionary)
 def analyse_characters(self,decoded_sequence):
  # as we are continously analysing so we don't want previous dictionary data
  self.char_dictionary={}
  n=0
  while n<len(decoded_sequence):
    # checking if character is already in char_dictionary
    if decoded_sequence[n] in self.char_dictionary:
     self.char_dictionary[decoded_sequence[n]] += 1
    else:
     self.char_dictionary[decoded_sequence[n]] = 1 
    n=n+1
  #for printing character stats.
  self.__str__()
