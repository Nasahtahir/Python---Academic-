#HASAN TAHIR
#ID: 29591732
#Last edit: 4/05/2018
class SentenceAnalyser:
 sentence_dictionary={}
 #constructor for intialising sentence_dictionary  on object creation of SentenceAnalyser.
 def __init__(self):
  sentence_dictionary={}

 #returns and prints sentence statistics in a readable format. 
 def __str__(self):
  print('Statistics for sentences :'+str(self.sentence_dictionary))
  for key, value in self.sentence_dictionary.items():
   print(key, '-', value)


 def analyse_sentences(self,decoded_sequence):
   self.sentence_dictionary={}
   i=0
   m=0
   while i<len(decoded_sequence):
    # we are finding sentences on the basis of punctuation marks and creating sentence dictionary on that basis.
    if  decoded_sequence[i]=="?" or  decoded_sequence[i]=="." or  decoded_sequence[i]==",":
     sentence=decoded_sequence[m:i+1]
     m=i+1
     if sentence!="":
      if sentence in self.sentence_dictionary:
       self.sentence_dictionary[sentence] += 1
      else:
       self.sentence_dictionary[sentence] = 1
    i=i+1
   #for the last sentence to be analysed.
   sentence=decoded_sequence[m:i]  
   if sentence!="":
    if sentence in self.sentence_dictionary:
     self.sentence_dictionary[sentence] += 1
    else:
     self.sentence_dictionary[sentence] = 1
   #printing dictionary .
   self.__str__()
 
